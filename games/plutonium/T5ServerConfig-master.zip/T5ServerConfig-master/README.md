# T5 Server Configs
This repo contains the T5 Dedicated Server Config for Plutonium T5.

Tutorials on how to use them can be found on:
* [Plutonium Docs](https://plutonium.pw/docs/server/t5/setting-up-a-server/)
