# T6ServerConfigs
This repo contains the T6 Dedicated Server Config for PlutoniumT6. Learn more by visiting the [Plutonium Documentation](https://plutonium.pw/docs/server/t6/setting-up-a-server/)

Or one of our communities tutorial's
* [AWOG Community Forum](https://forum.awog.at/topic/32/)
